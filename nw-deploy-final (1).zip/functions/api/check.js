export async function onRequestPost(context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
  };

  let body;
  try { body = await context.request.json(); }
  catch { return new Response(JSON.stringify({ error: 'bad json' }), { status: 400, headers }); }

  const { url } = body || {};
  if (!url) return new Response(JSON.stringify({ error: 'missing url' }), { status: 400, headers });

  let parsed;
  try {
    parsed = new URL(url);
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error();
  } catch {
    return new Response(JSON.stringify({ error: 'invalid url' }), { status: 400, headers });
  }

  const start = Date.now();
  let httpCode = null, status = 'down', responseTime = null, error = null;

  try {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), 10000);

    const res = await fetch(parsed.toString(), {
      method: 'HEAD',
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; StatusBot/1.0)',
        'Accept': '*/*',
      },
    });

    clearTimeout(tid);
    responseTime = Date.now() - start;
    httpCode = res.status;

    // 2xx, 3xx, 4xx = server is UP and responding
    // 5xx = server error = DOWN
    // We treat 403/401/404 as UP because the server IS reachable, just restricting access
    if (httpCode >= 200 && httpCode < 500) {
      status = 'up';
    } else {
      status = 'down';
      error = `HTTP ${httpCode}`;
    }
  } catch (e) {
    responseTime = Date.now() - start;
    error = e.name === 'AbortError' ? 'timeout' : 'unreachable';
    status = 'down';
  }

  return new Response(
    JSON.stringify({ url, status, httpCode, responseTime, error }),
    { status: 200, headers }
  );
}

export async function onRequestOptions() {
  return new Response(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
